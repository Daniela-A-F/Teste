package br.com.bancoPan.models;

import java.io.Serializable;
import java.text.*;
import java.util.Locale;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
 
@JsonIgnoreProperties(ignoreUnknown = true)

public class Estado implements Comparable<Estado>,Serializable{
	
	private static final long serialVersionUID = 1L;

		private int id;
		private String sigla;
		private String nome;
		private Regiao regiao;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getSigla() {
			return sigla;
		}

		public void setSigla(String sigla) {
			this.sigla = sigla;
		}
		
		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}
		
		public Regiao getRegiao() {
			return regiao;
		}

		public void setRegiao(Regiao regiao) {
			this.regiao = regiao;
		}
		
		public int compareTo (Estado estado) {
			 Collator cot = Collator.getInstance(new Locale("pt","BR"));
			    if(nome!= null)
			    return cot.compare(this.getNome(),estado.getNome());
			    else
			        return 0;
		}
		

	
}
