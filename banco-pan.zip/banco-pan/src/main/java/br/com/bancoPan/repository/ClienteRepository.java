package br.com.bancoPan.repository;

import java.util.ArrayList;
import br.com.bancoPan.models.Cliente;
import br.com.bancoPan.models.Endereco;

public class ClienteRepository {

	private ArrayList<Cliente> clientes;
	
	public ClienteRepository() {
		clientes  = new ArrayList<Cliente>();
		Cliente cliente = new Cliente();
		cliente.setId(1);
		cliente.setNome("Jo�o da silva");
		cliente.setCpf("11111111111");
		Endereco endereco = new Endereco();
		endereco.setId(1);
		endereco.setCep("09581560");
		endereco.setLogradouro("Avenida Bela Vista");
		endereco.setBairro("Jardim S�o Caetano");
		endereco.setLocalidade("S�o Caetano do Sul");
		endereco.setUf("SP");
		cliente.setEndereco(endereco);
		clientes.add(cliente);
		
		Cliente cliente2 = new Cliente();
		cliente2.setId(2);
		cliente2.setNome("Maria da Silva");
		cliente2.setCpf("22222222222");
		cliente.setEndereco(endereco);
		clientes.add(cliente2);
	}
	
    public ArrayList<Cliente> getList() {
        return clientes;
    }
     
    
	
	
}
