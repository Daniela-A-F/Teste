package br.com.bancoPan.Testes;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;
 

import br.com.bancoPan.services.*;

@RunWith(MockitoJUnitRunner.class)
public class EnderecoTest {

	 @BeforeMethod
	    public void initMock(){
	        MockitoAnnotations.initMocks(this);
	    }
	@Test
	public void findClientebyCPF()
	{
		EnderecoService enderecoService = Mockito.mock(EnderecoService.class);
	
		enderecoService.findByCep("09581560");
		Mockito.verify(enderecoService,Mockito.times(1)).findByCep("09581560");
		
	
	}
}
