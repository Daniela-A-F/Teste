package br.com.bancoPan.services;

import java.util.List;

import br.com.bancoPan.models.Municipio;

public interface MunicipioService {
	
	List<Municipio> findByUf(final String id);

}
