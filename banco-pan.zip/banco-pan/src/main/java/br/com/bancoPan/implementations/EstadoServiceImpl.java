package br.com.bancoPan.implementations;

import java.util.*;
import java.util.ArrayList;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;

import br.com.bancoPan.services.*;
import br.com.bancoPan.models.Estado;

@Service
public class EstadoServiceImpl implements EstadoService {

	// M�todo respons�vel por retornar uma lista de estados
	// atrav�s de consulta a um servi�o
	public List<Estado> findAll() {

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<List<Estado>> response = restTemplate.exchange(
				"https://servicodados.ibge.gov.br/api/v1/localidades/estados/", HttpMethod.GET, null,
				new ParameterizedTypeReference<List<Estado>>() {
				});
		List<Estado> estados = response.getBody();

		// Ordena��o da Lista em ordem alfab�tica
		Collections.sort(estados);


		List<Estado> estadosOrdenados = new ArrayList<Estado>(); 
		for(Estado e:estados) {

			/*Verifica se o item � S�o Paulo e 
		  	insere na primeira posi��o de uma segunda lista*/			  
			if(e.getId()==35) { 
				estadosOrdenados.add(0,e); 
			}
		}
		for(Estado e:estados)
		{
			/* Verifica se o item � Rio de Janeiro 
			 * 	e insere na segunda posi��o de uma segunda lista*/	
			if(e.getId()==33) {
				estadosOrdenados.add(1,e);        					
			}				
		}
		for(Estado e:estados)
		{	
			//	Adiciona o restante da lista j� ordenada por ordem alfab�tica	
			if(e.getId()!= 33 && e.getId()!=35) { 
				estadosOrdenados.add(e); 
			}
		}


		return estadosOrdenados;
	}
}