package br.com.bancoPan.implementations;

import br.com.bancoPan.models.*;
import br.com.bancoPan.services.*;
import br.com.bancoPan.repository.ClienteRepository; 
import org.springframework.stereotype.Service;

@Service
public class ClienteServiceImpl implements ClienteService {

	// M�todo respons�vel por retornar um cliente
	// usando CPF como par�metro
	// Database simulado atrav�s de uma lista em mem�ria 
	public Cliente findByCpf(String cpf) {
		Cliente cliente = new Cliente();
		ClienteRepository clienteRepository = new ClienteRepository();

		for(Cliente c:clienteRepository.getList())
		{
			if(cpf.equals(c.getCpf())) {
				cliente.setId(c.getId());
				cliente.setNome(c.getNome());
				cliente.setCpf(c.getCpf());
			}
		}
		return cliente;
	}
	
	public String UpdateEnderecoCliente(String cpf,Endereco endereco) {
		ClienteRepository clienteRepository = new ClienteRepository();

		for(Cliente c:clienteRepository.getList())
		{
			if(cpf.equals(c.getCpf())) {
				try {
					c.setEndereco(endereco);
					
				}catch(Exception e)
				{
					return "Erro na altera��o do endere�o!";
				}
				
				
			}		
			
		}
		return "Altera��o realizada com sucesso";
		
	}


}


