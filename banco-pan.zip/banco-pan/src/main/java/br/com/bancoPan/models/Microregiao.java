package br.com.bancoPan.models;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
 
@JsonIgnoreProperties(ignoreUnknown = true)
public class Microregiao implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String nome;
	private Mesoregiao mesoregiao;
	
	public Long getId() {
        return id;
    }
     
    public void setId(Long id) {
        this.id = id;
    }
	
    public String getNome() {
        return nome;
    }
     
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public Mesoregiao getMesoregiao() {
        return mesoregiao;
    }
     
    public void setMesoregiao(Mesoregiao mesoregiao) {
        this.mesoregiao = mesoregiao;
    }
    
    

}
