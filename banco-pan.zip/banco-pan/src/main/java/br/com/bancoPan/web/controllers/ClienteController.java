package br.com.bancoPan.web.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

import br.com.bancoPan.models.*;
import br.com.bancoPan.services.*;

/**
 * @author Daniela Andrade Fernandes
 * Cen�rio 1 - Consultar Cliente
 * +
 * Cen�rio 5 (B�nus) - Alterar endere�o do Cliente
 */

@RestController

@RequestMapping("/Cliente/")

public class ClienteController {

	@Autowired
	private ClienteService clienteService;

	@ResponseStatus(HttpStatus.OK) 
	@RequestMapping(value = "/{cpf}",
	method = RequestMethod.GET, 
	produces = MediaType.APPLICATION_JSON_VALUE)
	public Cliente get(@PathVariable(value = "cpf") String cpf){
		return clienteService.findByCpf(cpf);
	}
	
	@ResponseStatus(HttpStatus.OK) 
	@RequestMapping(value = "/UpdateEnderecoCliente",
	method = RequestMethod.POST, 
	produces = MediaType.TEXT_PLAIN_VALUE)
	public String UpdateEndereco(@RequestBody Cliente cliente) {
		Endereco endereco = new Endereco();
		endereco = cliente.getEndereco();
		String cpf = cliente.getCpf();
		return clienteService.UpdateEnderecoCliente(cpf, endereco);
	}
}
