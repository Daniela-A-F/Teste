package br.com.bancoPan.implementations;

import org.springframework.web.client.RestTemplate;
import org.springframework.stereotype.Service;

import br.com.bancoPan.models.Endereco;
import br.com.bancoPan.services.EnderecoService;

@Service
public class EnderecoServiceImpl implements EnderecoService {

	// M�todo respons�vel por retornar um endere�o
	// usando CEP como par�metro
	// consultando um servi�o 
	public Endereco findByCep(String cep) {
		RestTemplate template = new RestTemplate();
		return template.getForObject("https://viacep.com.br/ws/{cep}/json",Endereco.class, cep);

	}

}
