package br.com.bancoPan.Testes;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;


import br.com.bancoPan.services.*;

@RunWith(MockitoJUnitRunner.class)
public class MunicipioTest {
	
	@BeforeMethod
	public void initMock(){
		MockitoAnnotations.initMocks(this);
	}
	@Test
	public void findClientebyCPF()
	{
		MunicipioService municipioService = Mockito.mock(MunicipioService.class);
		municipioService.findByUf("35");
		Mockito.verify(municipioService,Mockito.times(1)).findByUf("35");
		

	}


}
