package br.com.bancoPan.services;

import java.util.List;

import br.com.bancoPan.models.Estado;

public interface EstadoService {
		
	List<Estado> findAll();

}
