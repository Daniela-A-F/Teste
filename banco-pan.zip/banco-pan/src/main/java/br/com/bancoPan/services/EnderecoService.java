package br.com.bancoPan.services;

import br.com.bancoPan.models.Endereco;

public interface EnderecoService {
	
	Endereco findByCep(final String cep);    

}
