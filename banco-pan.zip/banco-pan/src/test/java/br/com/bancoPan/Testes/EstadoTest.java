package br.com.bancoPan.Testes;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;


import br.com.bancoPan.services.*;

@RunWith(MockitoJUnitRunner.class)
public class EstadoTest {
	
	@BeforeMethod
	public void initMock(){
		MockitoAnnotations.initMocks(this);
	}
	@Test
	public void findClientebyCPF()
	{
		EstadoService estadoService = Mockito.mock(EstadoService.class);

		estadoService.findAll();
		Mockito.verify(estadoService,Mockito.times(1)).findAll();


	}

}
