package br.com.bancoPan.implementations;

import java.util.*;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;

import br.com.bancoPan.services.MunicipioService;
import br.com.bancoPan.models.Municipio;

@Service
public class MunicipioServiceImpl implements MunicipioService{

	public List<Municipio> findByUf(String id){
		
		RestTemplate restTemplate = new RestTemplate();
    	ResponseEntity<List<Municipio>> response = restTemplate.exchange(
    	  "https://servicodados.ibge.gov.br/api/v1/localidades/estados/{id}/municipios",
    	  HttpMethod.GET,
    	  null,
    	  new ParameterizedTypeReference<List<Municipio>>(){},
    	  id);
    	List<Municipio> municipios = response.getBody();

        return municipios;
		

	}
}
