package br.com.bancoPan.services;


import br.com.bancoPan.models.Cliente;
import br.com.bancoPan.models.Endereco;

public interface ClienteService {

	Cliente findByCpf(final String cpf);
	
	String UpdateEnderecoCliente(String cpf,Endereco endereco);


}
