package br.com.bancoPan.models;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

 
@JsonIgnoreProperties(ignoreUnknown = true)
public class Mesoregiao implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long id;
	private String nome;
	private Estado uf;
	
	public Long getId() {
        return id;
    }
     
    public void setId(Long id) {
        this.id = id;
    }
	
    public String getNome() {
        return nome;
    }
     
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public Estado getUf() {
        return uf;
    }
     
    public void setUf(Estado uf) {
        this.uf = uf;
    }
    
}
